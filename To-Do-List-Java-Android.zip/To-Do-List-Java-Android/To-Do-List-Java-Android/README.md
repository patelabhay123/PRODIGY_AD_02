# To-Do-List---Java-Android-Application
 
Built (and fully-tested) using Gradle in Android Studio IDE.  

Ability to maintain a task-list with date input, all entries viewed in list form, full details can be recalled where tasks can be marked as complete.

<img width="265" alt="screen shot 2017-07-31 at 21 00 32" src="https://user-images.githubusercontent.com/27961809/29252822-2d0b58b8-8066-11e7-967b-218fd9318d86.png">
<img width="265" alt="screen shot 2017-07-31 at 21 03 48" src="https://user-images.githubusercontent.com/27961809/29252824-317e65fc-8066-11e7-80b4-46f31f1cea3a.png">
<img width="263" alt="screen shot 2017-07-31 at 21 06 47" src="https://user-images.githubusercontent.com/27961809/29252825-388c6efc-8066-11e7-909b-d29f9e03fe18.png">
<img width="263" alt="screen shot 2017-07-31 at 21 06 26" src="https://user-images.githubusercontent.com/27961809/29252828-3f092e14-8066-11e7-93b4-c1733626ed75.png">
<img width="266" alt="screen shot 2017-07-31 at 21 07 15" src="https://user-images.githubusercontent.com/27961809/29252829-417de22a-8066-11e7-8af7-9af782eb3c0a.png">
